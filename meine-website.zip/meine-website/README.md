# Meine Website

Ein einfaches Template mit drei Seiten:

- **index.html** – Startseite  
- **about.html** – Über uns  
- **contact.html** – Kontakt

## Deployment

1. Neues GitHub-Repo anlegen  
2. Dateien hochladen / pushen  
3. GitHub Pages in den Repo-Settings aktivieren  
4. Fertig!